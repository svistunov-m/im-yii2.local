<?php

function __($arr) {
    echo "<pre>" . print_r($arr, true) . "</pre>";
    die;
}

function debug($arr) {
    echo "<pre>" . print_r($arr, true) . "</pre>";
}