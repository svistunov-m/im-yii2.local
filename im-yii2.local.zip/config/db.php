<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=im-yii2.local',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
